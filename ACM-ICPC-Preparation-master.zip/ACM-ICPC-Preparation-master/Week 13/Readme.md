# Week 13


## Heaps (Priority Queues)

#### [Tutorial]()

#### Other Study Sources
- [HackerEarth](https://www.hackerearth.com/practice/data-structures/trees/heapspriority-queues/tutorial/)
- [GeeksforGeeks](https://www.geeksforgeeks.org/heap-data-structure/)

#### Questions
- [Kth Largest Element in an Array](https://leetcode.com/problems/kth-largest-element-in-an-array/description/)
   - [Java Solution](https://github.com/rajat123456/General-Competitive-Programming-Questions/blob/master/(LeetCode)Kth%20Largest%20Using%20Heaps.java)
- [Merge K Sorted Arrays](https://www.geeksforgeeks.org/merge-k-sorted-arrays/)   
- [Median in a stream of integers](https://www.geeksforgeeks.org/median-of-stream-of-integers-running-integers/)
